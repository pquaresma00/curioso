import { supabase } from "@/integrations/supabase/client";

export type ServiceRow = {
  id: string;
  title: string;
  description: string;
  badge: string | null;
  images: string[];
  highlight: boolean;
  active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

export async function fetchPublicServices(): Promise<ServiceRow[]> {
  const { data, error } = await supabase
    .from("services")
    .select("*")
    .eq("active", true)
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as ServiceRow[];
}

export async function fetchAllServices(): Promise<ServiceRow[]> {
  const { data, error } = await supabase
    .from("services")
    .select("*")
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data ?? []) as ServiceRow[];
}
