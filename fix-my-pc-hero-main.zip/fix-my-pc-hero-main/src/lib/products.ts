import { supabase } from "@/integrations/supabase/client";

export type ProductRow = {
  id: string;
  name: string;
  description: string;
  long_description: string;
  price: number;
  old_price: number | null;
  category: string;
  image_url: string;
  badge: string | null;
  highlight: boolean;
  active: boolean;
  specs: string[];
  sort_order: number;
  created_at: string;
  updated_at: string;
};

export async function fetchPublicProducts(): Promise<ProductRow[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .eq("active", true)
    .order("sort_order", { ascending: false });
  if (error) throw error;
  return (data ?? []) as ProductRow[];
}

export async function fetchAllProducts(): Promise<ProductRow[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("sort_order", { ascending: false });
  if (error) throw error;
  return (data ?? []) as ProductRow[];
}

export type SiteContent = {
  home: {
    heroTitle: string;
    heroSubtitle: string;
    heroCta: string;
    aboutTitle: string;
    aboutText: string;
  };
  contact: {
    phone: string;
    whatsapp: string;
    email: string;
    address: string;
    hours: string;
    instagram: string;
    facebook: string;
  };
};

export async function fetchSiteContent<K extends keyof SiteContent>(key: K): Promise<SiteContent[K] | null> {
  const { data, error } = await supabase
    .from("site_content")
    .select("value")
    .eq("key", key)
    .maybeSingle();
  if (error) throw error;
  return (data?.value as SiteContent[K]) ?? null;
}
