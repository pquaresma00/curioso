import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Award, Quote, MapPin, Clock, Users, Wrench, Sparkles, Shield, Eye } from "lucide-react";
import lojaFachada from "@/assets/loja-fachada.png";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Sobre nós — Solução Celular" },
      { name: "description", content: "Mais que técnica, uma história de confiança com você. Conheça a Solução Celular: 20 anos de experiência e 11 anos em Rio das Ostras especialistas em smartphones." },
      { property: "og:title", content: "Sobre nós — Solução Celular" },
      { property: "og:description", content: "Mais que técnica, uma história de confiança com você. Especialistas em smartphones em Rio das Ostras há 11 anos." },
      { property: "og:image", content: lojaFachada },
      { name: "twitter:image", content: lojaFachada },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="bg-background">
      {/* Cabeçalho com foto da loja como background */}
      <section className="relative w-full overflow-hidden border-b border-border pt-24 pb-10 min-h-[60vh] flex items-end">
        {/* Imagem de fundo */}
        <img
          src={lojaFachada}
          alt="Fachada da loja Solução Celular em Rio das Ostras"
          className="absolute inset-0 h-full w-full object-cover object-[center_8%] scale-110"
          loading="eager"
        />
        {/* Overlays para harmonizar com a identidade do site */}
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/40 to-background" />
        <div className="absolute inset-0 bg-gradient-to-tr from-primary/30 via-transparent to-transparent mix-blend-multiply" />

        {/* Badge de localização flutuante */}
        <div className="relative z-10 mx-auto w-full px-4 sm:px-6 lg:px-8 flex justify-center pb-4">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="inline-flex items-center gap-2 rounded-full bg-background/80 backdrop-blur-md border border-primary/30 px-4 py-2 text-xs sm:text-sm font-medium text-foreground shadow-lg"
          >
            <MapPin className="h-4 w-4 text-primary shrink-0" />
            <span>Rua Santa Catarina, 666 — Cidade Praiana, Rio das Ostras</span>
          </motion.span>
        </div>
      </section>

      {/* Quem Somos — com título principal no topo */}
      <section className="pt-16 pb-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-14"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-semibold text-primary uppercase tracking-wider">
              <Award className="h-3.5 w-3.5" />
              + de 20 anos de tradição
            </span>
            <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
              Sobre a <span className="text-primary">Solução Celular</span>
            </h1>
            <p className="mt-4 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
              Mais que técnica, uma história de confiança com você
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                  <circle cx="9" cy="7" r="4"/>
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87"/>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
              </div>
              <span className="text-sm font-semibold text-primary uppercase tracking-wider">Nossa História</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">Quem Somos</h2>
            <div className="space-y-5 text-base sm:text-lg text-muted-foreground leading-relaxed">
              <p>
                A <strong className="text-foreground">Solução Celular</strong> não nasceu ontem. Nossa marca carrega uma bagagem de mais de 20 anos de experiência no mercado de tecnologia. Duas décadas acompanhando cada evolução, do primeiro tijolão aos smartphones mais avançados do mundo.
              </p>
              <p>
                Mas sabemos que tradição só faz sentido se vier acompanhada de proximidade. É por isso que, há 11 anos, escolhemos <strong className="text-foreground">Rio das Ostras</strong> para fincar nossas raízes e oferecer o que há de melhor em assistência técnica para a nossa região.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Sua vida não pode parar */}
      <section className="py-20 bg-surface border-y border-border">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <Clock className="h-6 w-6" />
              </div>
              <span className="text-sm font-semibold text-primary uppercase tracking-wider">Nossa Missão</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Sua vida não pode parar
            </h2>
            <div className="space-y-5 text-base sm:text-lg text-muted-foreground leading-relaxed">
              <p>
                Nós entendemos que o seu celular não é apenas um aparelho. É onde você guarda as fotos dos seus filhos, onde fecha seus negócios e como se comunica com quem ama. Quando ele quebra, a sensação é de que a rotina trava.
              </p>
              <p>
                Nossa missão é <strong className="text-foreground">destravar a sua vida com agilidade e transparência</strong>. Nesses 11 anos em Rio das Ostras, nos tornamos a solução definitiva porque nunca fugimos do nosso foco: somos especialistas em smartphones. Enquanto muitos tentam abraçar tudo, nós preferimos ser os melhores naquilo que fazemos de verdade.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* O que nos diferencia? */}
      <section className="py-20">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              O que nos diferencia?
            </h2>

            <div className="grid gap-6 sm:grid-cols-3 mb-12">
              {[
                { icon: Users, title: "Especialistas de Verdade", desc: "Nossa equipe não parou no tempo. Estamos em constante aprendizado, com profissionais qualificados que entendem a engenharia de cada marca." },
                { icon: Sparkles, title: "Compromisso com o Original", desc: "Valorizamos o seu investimento. Por isso, trabalhamos com produtos de alta qualidade e procedência, garantindo que o seu aparelho volte a ter a performance de um novo." },
                { icon: Eye, title: "Transparência Total", desc: "Mais de 20 anos de mercado nos ensinaram que a honestidade é o único caminho. Aqui, o diagnóstico é claro, sem letras miúdas." },
              ].map((item, i) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="rounded-xl border border-border bg-background p-6 hover:border-primary/40 hover:-translate-y-1 transition-all"
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/15 text-primary mb-4">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>

            {/* Estatísticas */}
            <div className="grid gap-4 sm:grid-cols-3 mb-12">
              {[
                { icon: Clock, value: "20+", label: "Anos no mercado" },
                { icon: MapPin, value: "11", label: "Anos em Rio das Ostras" },
                { icon: Users, value: "Milhares", label: "De clientes atendidos" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-xl border border-border bg-surface p-6 text-center">
                  <stat.icon className="h-6 w-6 text-primary mx-auto mb-3" />
                  <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Citação */}
            <motion.blockquote
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-transparent p-8 sm:p-10"
            >
              <Quote className="h-10 w-10 text-primary/60 mb-4" />
              <p className="text-xl sm:text-2xl font-medium text-foreground italic leading-relaxed">
                "Solução Celular: A solução que você precisa, com a confiança que você já conhece."
              </p>
            </motion.blockquote>
          </motion.div>
        </div>
      </section>

      {/* De Rio das Ostras para você */}
      <section className="py-20 bg-surface border-y border-border">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <MapPin className="h-6 w-6" />
              </div>
              <span className="text-sm font-semibold text-primary uppercase tracking-wider">Nossa Origem</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              De Rio das Ostras para você
            </h2>
            <div className="space-y-5 text-base sm:text-lg text-muted-foreground leading-relaxed">
              <p>
                Nossa loja de 11 anos não é apenas um ponto comercial; é um lugar onde criamos amigos e clientes fiéis. Se você busca uma empresa que une a experiência de quem tem 20 anos de estrada com o atendimento humano de quem está ao seu lado há mais de uma década, você encontrou.
              </p>
              <p className="text-lg font-medium text-foreground">
                <strong>Solução Celular:</strong> A solução que você precisa, com a confiança que você já conhece.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              Venha nos visitar
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Descubra por que somos a solução definitiva para o seu celular há mais de duas décadas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="https://wa.me/5522998842964?text=Ol%C3%A1!%20Gostaria%20de%20falar%20com%20a%20Solu%C3%A7%C3%A3o%20Celular."
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 glow-box"
              >
                Falar com a gente
              </a>
              <Link
                to="/products"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-border bg-surface px-6 py-3 text-sm font-semibold text-foreground transition-all hover:border-primary/50"
              >
                Ver nossos produtos
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
