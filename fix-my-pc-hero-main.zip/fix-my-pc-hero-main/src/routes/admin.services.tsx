import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchAllServices, type ServiceRow } from "@/lib/services";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import {
  Plus, Pencil, Trash2, Loader2, Upload, Eye, EyeOff,
  ArrowUp, ArrowDown, X, ImageIcon,
} from "lucide-react";

export const Route = createFileRoute("/admin/services")({
  component: AdminServicesPage,
});

type FormState = {
  id?: string;
  title: string;
  description: string;
  badge: string;
  images: string[];
  highlight: boolean;
  active: boolean;
  sort_order: string;
};

const emptyForm: FormState = {
  title: "",
  description: "",
  badge: "",
  images: [],
  highlight: false,
  active: true,
  sort_order: "0",
};

function AdminServicesPage() {
  const [services, setServices] = useState<ServiceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      setServices(await fetchAllServices());
    } catch {
      toast.error("Erro ao carregar serviços");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const openNew = () => {
    setForm({ ...emptyForm, sort_order: String((services.at(-1)?.sort_order ?? 0) + 1) });
    setDialogOpen(true);
  };

  const openEdit = (s: ServiceRow) => {
    setForm({
      id: s.id,
      title: s.title,
      description: s.description,
      badge: s.badge ?? "",
      images: [...s.images],
      highlight: s.highlight,
      active: s.active,
      sort_order: String(s.sort_order),
    });
    setDialogOpen(true);
  };

  const handleUploadFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      const uploaded: string[] = [];
      for (const file of Array.from(files)) {
        const ext = file.name.split(".").pop() || "png";
        const path = `services/${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from("product-images").upload(path, file, {
          cacheControl: "3600",
          upsert: false,
        });
        if (error) throw error;
        const { data } = supabase.storage.from("product-images").getPublicUrl(path);
        uploaded.push(data.publicUrl);
      }
      setForm((f) => ({ ...f, images: [...f.images, ...uploaded] }));
      toast.success(`${uploaded.length} imagem(ns) enviada(s)`);
    } catch (e: any) {
      toast.error(e.message ?? "Erro ao enviar imagens");
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (index: number) => {
    setForm((f) => ({ ...f, images: f.images.filter((_, i) => i !== index) }));
  };

  const moveImage = (index: number, dir: -1 | 1) => {
    setForm((f) => {
      const next = [...f.images];
      const target = index + dir;
      if (target < 0 || target >= next.length) return f;
      [next[index], next[target]] = [next[target], next[index]];
      return { ...f, images: next };
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        description: form.description.trim(),
        badge: form.badge.trim() || null,
        images: form.images,
        highlight: form.highlight,
        active: form.active,
        sort_order: Number(form.sort_order) || 0,
      };

      if (!payload.title) {
        toast.error("Título é obrigatório");
        setSaving(false);
        return;
      }

      if (form.id) {
        const { error } = await supabase.from("services").update(payload).eq("id", form.id);
        if (error) throw error;
        toast.success("Serviço atualizado");
      } else {
        const { error } = await supabase.from("services").insert(payload);
        if (error) throw error;
        toast.success("Serviço criado");
      }
      setDialogOpen(false);
      load();
    } catch (e: any) {
      toast.error(e.message ?? "Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (s: ServiceRow) => {
    const { error } = await supabase.from("services").update({ active: !s.active }).eq("id", s.id);
    if (error) toast.error(error.message);
    else {
      toast.success(s.active ? "Serviço ocultado" : "Serviço publicado");
      load();
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    const { error } = await supabase.from("services").delete().eq("id", deleteId);
    if (error) toast.error(error.message);
    else {
      toast.success("Serviço excluído");
      load();
    }
    setDeleteId(null);
  };

  const reorder = async (s: ServiceRow, dir: -1 | 1) => {
    const sorted = [...services].sort((a, b) => a.sort_order - b.sort_order);
    const idx = sorted.findIndex((x) => x.id === s.id);
    const target = idx + dir;
    if (target < 0 || target >= sorted.length) return;
    const other = sorted[target];
    const a = supabase.from("services").update({ sort_order: other.sort_order }).eq("id", s.id);
    const b = supabase.from("services").update({ sort_order: s.sort_order }).eq("id", other.id);
    const [r1, r2] = await Promise.all([a, b]);
    if (r1.error || r2.error) {
      toast.error("Erro ao reordenar");
    } else {
      load();
    }
  };

  return (
    <div className="p-6 lg:p-10 max-w-7xl">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-foreground">Serviços</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {services.length} serviços cadastrados — aparecem na seção "Nossos serviços" da home
          </p>
        </div>
        <Button onClick={openNew}>
          <Plus className="h-4 w-4 mr-2" /> Novo serviço
        </Button>
      </div>

      {loading ? (
        <div className="grid place-items-center py-20">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left">
              <tr>
                <th className="px-4 py-3 font-semibold w-20">Ordem</th>
                <th className="px-4 py-3 font-semibold">Serviço</th>
                <th className="px-4 py-3 font-semibold">Imagens</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 font-semibold text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {services.map((s, i) => (
                <tr key={s.id} className="hover:bg-muted/30">
                  <td className="px-4 py-3">
                    <div className="flex flex-col items-center gap-0.5">
                      <button onClick={() => reorder(s, -1)} disabled={i === 0} className="text-muted-foreground hover:text-foreground disabled:opacity-30">
                        <ArrowUp className="h-3.5 w-3.5" />
                      </button>
                      <span className="text-xs text-muted-foreground">{s.sort_order}</span>
                      <button onClick={() => reorder(s, 1)} disabled={i === services.length - 1} className="text-muted-foreground hover:text-foreground disabled:opacity-30">
                        <ArrowDown className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-12 rounded-md bg-muted overflow-hidden flex-shrink-0 grid place-items-center">
                        {s.images[0] ? (
                          <img src={s.images[0]} alt={s.title} className="h-full w-full object-cover" />
                        ) : (
                          <ImageIcon className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{s.title}</p>
                        <p className="text-xs text-muted-foreground line-clamp-1 max-w-md">{s.description}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{s.images.length}</td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => toggleActive(s)}
                      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${
                        s.active
                          ? "bg-green-500/15 text-green-600 dark:text-green-400"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {s.active ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                      {s.active ? "Ativo" : "Oculto"}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex items-center gap-1">
                      <Button size="icon" variant="ghost" onClick={() => openEdit(s)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => setDeleteId(s.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
              {services.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-12 text-center text-muted-foreground text-sm">
                    Nenhum serviço cadastrado
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{form.id ? "Editar serviço" : "Novo serviço"}</DialogTitle>
            <DialogDescription>
              Adicione várias imagens — o cliente verá um carrossel arrastável no card.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input id="title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea id="description" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="badge">Selo (opcional)</Label>
                <Input id="badge" value={form.badge} onChange={(e) => setForm({ ...form, badge: e.target.value })} placeholder="Ex: 1 ano de garantia" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sort_order">Ordem</Label>
                <Input id="sort_order" type="number" value={form.sort_order} onChange={(e) => setForm({ ...form, sort_order: e.target.value })} />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Imagens ({form.images.length})</Label>
                <label className="inline-flex items-center gap-1.5 text-xs font-medium text-primary cursor-pointer hover:underline">
                  <Upload className="h-3.5 w-3.5" />
                  Adicionar imagens
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    disabled={uploading}
                    onChange={(e) => {
                      handleUploadFiles(e.target.files);
                      e.target.value = "";
                    }}
                  />
                </label>
              </div>
              {uploading && (
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Loader2 className="h-3 w-3 animate-spin" /> Enviando...
                </p>
              )}
              {form.images.length === 0 ? (
                <div className="rounded-lg border-2 border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                  Nenhuma imagem. Clique em "Adicionar imagens" acima.
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {form.images.map((url, i) => (
                    <div key={i} className="relative group rounded-lg overflow-hidden border border-border bg-muted aspect-square">
                      <img src={url} alt={`Imagem ${i + 1}`} className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1">
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={() => moveImage(i, -1)}
                            disabled={i === 0}
                            className="h-7 w-7 rounded bg-background/90 grid place-items-center disabled:opacity-30"
                            title="Mover para esquerda"
                          >
                            <ArrowUp className="h-3.5 w-3.5 -rotate-90" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveImage(i, 1)}
                            disabled={i === form.images.length - 1}
                            className="h-7 w-7 rounded bg-background/90 grid place-items-center disabled:opacity-30"
                            title="Mover para direita"
                          >
                            <ArrowDown className="h-3.5 w-3.5 -rotate-90" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeImage(i)}
                            className="h-7 w-7 rounded bg-destructive grid place-items-center text-destructive-foreground"
                            title="Remover"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        {i === 0 && <span className="text-[10px] text-white font-semibold">PRINCIPAL</span>}
                      </div>
                      {i === 0 && (
                        <span className="absolute top-1 left-1 text-[9px] font-bold uppercase bg-primary text-primary-foreground px-1.5 py-0.5 rounded">
                          1ª
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Switch checked={form.highlight} onCheckedChange={(v) => setForm({ ...form, highlight: v })} />
                <Label>Em destaque</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
                <Label>Publicado</Label>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir serviço?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive hover:bg-destructive/90">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
