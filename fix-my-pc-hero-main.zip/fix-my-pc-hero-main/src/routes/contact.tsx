import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Clock, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contato — Solução Celular" },
      { name: "description", content: "Entre em contato com a Solução Celular. Diagnóstico gratuito, atendimento rápido por telefone, WhatsApp ou e-mail." },
      { property: "og:title", content: "Contato — Solução Celular" },
      { property: "og:description", content: "Fale com a Solução Celular para um diagnóstico gratuito do seu equipamento." },
    ],
  }),
  component: ContactPage,
});

const contactInfo = [
  { icon: Phone, label: "Telefone", value: "(11) 99999-9999", href: "tel:+5511999999999" },
  { icon: MessageCircle, label: "WhatsApp", value: "(11) 99999-9999", href: "https://wa.me/5511999999999" },
  { icon: Mail, label: "E-mail", value: "contato@techfix.com.br", href: "mailto:contato@techfix.com.br" },
  { icon: MapPin, label: "Endereço", value: "Rua Exemplo, 123 — São Paulo, SP", href: undefined },
  { icon: Clock, label: "Horário", value: "Seg a Sex: 9h–18h | Sáb: 9h–13h", href: undefined },
];

function ContactPage() {
  return (
    <div className="pt-24 pb-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-extrabold sm:text-5xl">
            Fale <span className="text-gradient">conosco</span>
          </h1>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Diagnóstico gratuito e sem compromisso. Escolha o canal mais conveniente.
          </p>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 max-w-4xl mx-auto">
          {contactInfo.map((item, i) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              {item.href ? (
                <a
                  href={item.href}
                  target={item.href.startsWith("http") ? "_blank" : undefined}
                  rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className="flex flex-col items-center rounded-2xl border border-border bg-card p-8 text-center transition-all hover:glow-border hover:shadow-lg hover:shadow-primary/5"
                >
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                    <item.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">{item.label}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{item.value}</p>
                </a>
              ) : (
                <div className="flex flex-col items-center rounded-2xl border border-border bg-card p-8 text-center">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
                    <item.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground">{item.label}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{item.value}</p>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-16 rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 to-transparent p-12 text-center max-w-2xl mx-auto glow-box"
        >
          <h2 className="text-2xl font-bold text-foreground">Precisa de atendimento urgente?</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Ligue agora ou mande uma mensagem no WhatsApp. Respondemos em minutos.
          </p>
          <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
            <a
              href="tel:+5511999999999"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-3.5 text-sm font-bold text-primary-foreground hover:opacity-90"
            >
              <Phone className="h-4 w-4" />
              Ligar agora
            </a>
            <a
              href="https://wa.me/5511999999999"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-xl border border-border bg-secondary px-8 py-3.5 text-sm font-medium text-secondary-foreground hover:bg-muted"
            >
              <MessageCircle className="h-4 w-4" />
              WhatsApp
            </a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
