import { createFileRoute } from "@tanstack/react-router";
import { HeroSection } from "../components/HeroSection";
import { ServicesPreview } from "../components/ServicesPreview";
import { TestimonialsSection } from "../components/TestimonialsSection";
import { CtaSection } from "../components/CtaSection";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Solução Celular — Assistência Técnica" },
      { name: "description", content: "Consertamos computadores, notebooks, celulares e tablets com agilidade, transparência e garantia. Diagnóstico gratuito." },
      { property: "og:title", content: "Solução Celular — Assistência Técnica" },
      { property: "og:description", content: "Consertamos computadores, notebooks, celulares e tablets com agilidade, transparência e garantia." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <HeroSection />
      <ServicesPreview />
      <TestimonialsSection />
      <CtaSection />
    </>
  );
}
