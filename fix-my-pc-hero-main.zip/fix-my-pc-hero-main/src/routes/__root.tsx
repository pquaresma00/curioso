import { Outlet, Link, createRootRoute, HeadContent, Scripts, useRouterState } from "@tanstack/react-router";
import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { AuthProvider } from "@/lib/auth";
import { Toaster } from "@/components/ui/sonner";
import "../styles.css";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Página não encontrada</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A página que você procura não existe ou foi movida.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Voltar ao início
          </Link>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Solução Celular — Assistência Técnica" },
      { name: "description", content: "Assistência técnica especializada em computadores, notebooks e celulares. Diagnóstico gratuito." },
      { name: "author", content: "Solução Celular" },
      { property: "og:type", content: "website" },
      { property: "og:title", content: "Solução Celular — Assistência Técnica" },
      { name: "twitter:title", content: "Solução Celular — Assistência Técnica" },
      { property: "og:description", content: "Assistência técnica especializada em computadores, notebooks e celulares. Diagnóstico gratuito." },
      { name: "twitter:description", content: "Assistência técnica especializada em computadores, notebooks e celulares. Diagnóstico gratuito." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fe911b95-c54c-4080-b8ba-7b1f55b1ad85/id-preview-7e27e964--34c7c910-597a-4ba8-afbc-fcb53ec0704d.lovable.app-1776531391550.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/fe911b95-c54c-4080-b8ba-7b1f55b1ad85/id-preview-7e27e964--34c7c910-597a-4ba8-afbc-fcb53ec0704d.lovable.app-1776531391550.png" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "apple-touch-icon", href: "/favicon.png" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isAdminArea = pathname.startsWith("/admin") || pathname === "/login";

  return (
    <AuthProvider>
      {!isAdminArea && <Header />}
      <main>
        <Outlet />
      </main>
      {!isAdminArea && <Footer />}
      <Toaster richColors position="top-right" />
    </AuthProvider>
  );
}
