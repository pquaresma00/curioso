import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Loader2, Lock } from "lucide-react";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login Admin — Solução Celular" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: LoginPage,
});

const USERNAME_DOMAIN = "solucao.local";

function normalizeUsername(raw: string) {
  return raw.trim().toLowerCase().replace(/[^a-z0-9_.-]/g, "");
}

function usernameToEmail(username: string) {
  return `${normalizeUsername(username)}@${USERNAME_DOMAIN}`;
}

function LoginPage() {
  const { user, isAdmin, loading, signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      if (isAdmin) navigate({ to: "/admin" });
    }
  }, [user, isAdmin, loading, navigate]);

  const validateUsername = () => {
    const clean = normalizeUsername(username);
    if (clean.length < 3) {
      toast.error("Usuário precisa ter ao menos 3 caracteres (letras, números, . _ -)");
      return null;
    }
    return clean;
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = validateUsername();
    if (!clean) return;
    setSubmitting(true);
    const { error } = await signIn(usernameToEmail(clean), password);
    setSubmitting(false);
    if (error) toast.error("Usuário ou senha incorretos");
    else toast.success("Bem-vindo!");
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = validateUsername();
    if (!clean) return;
    if (password.length < 8) {
      toast.error("Senha precisa ter ao menos 8 caracteres");
      return;
    }
    setSubmitting(true);
    const { error } = await signUp(usernameToEmail(clean), password);
    setSubmitting(false);
    if (error) toast.error(error);
    else toast.success("Conta criada! Faça login para entrar.");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-16">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
            <Lock className="h-6 w-6" />
          </div>
          <h1 className="text-2xl font-extrabold text-foreground">Painel Administrativo</h1>
          <p className="mt-1 text-sm text-muted-foreground">Acesso restrito à equipe</p>
        </div>

        <Card>
          <Tabs defaultValue="signin">
            <CardHeader>
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="signin">Entrar</TabsTrigger>
                <TabsTrigger value="signup">Criar conta</TabsTrigger>
              </TabsList>
            </CardHeader>

            <TabsContent value="signin">
              <form onSubmit={handleSignIn}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-username">Usuário</Label>
                    <Input
                      id="signin-username"
                      type="text"
                      autoComplete="username"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="seu_usuario"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signin-password">Senha</Label>
                    <Input
                      id="signin-password"
                      type="password"
                      autoComplete="current-password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Entrar
                  </Button>
                </CardContent>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignUp}>
                <CardContent className="space-y-4">
                  <CardDescription className="text-xs">
                    Crie a primeira conta para se tornar admin (a primeira conta criada vira admin automaticamente).
                  </CardDescription>
                  <div className="space-y-2">
                    <Label htmlFor="signup-username">Usuário</Label>
                    <Input
                      id="signup-username"
                      type="text"
                      autoComplete="username"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="ex: admin"
                    />
                    <p className="text-[11px] text-muted-foreground">
                      Use letras, números ou os caracteres . _ - (mínimo 3).
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Senha (mín. 8 caracteres)</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      autoComplete="new-password"
                      required
                      minLength={8}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={submitting}>
                    {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Criar conta
                  </Button>
                </CardContent>
              </form>
            </TabsContent>
          </Tabs>
        </Card>

        <div className="mt-6 text-center">
          <Link to="/" className="text-xs text-muted-foreground hover:text-foreground">
            ← Voltar para o site
          </Link>
        </div>
      </div>
    </div>
  );
}
