import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchSiteContent, type SiteContent } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/admin/home")({
  component: AdminHomePage,
});

const defaults: SiteContent["home"] = {
  heroTitle: "",
  heroSubtitle: "",
  heroCta: "",
  aboutTitle: "",
  aboutText: "",
};

function AdminHomePage() {
  const [data, setData] = useState<SiteContent["home"]>(defaults);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSiteContent("home").then((d) => {
      if (d) setData({ ...defaults, ...d });
      setLoading(false);
    });
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase
      .from("site_content")
      .upsert({ key: "home", value: data });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Conteúdo salvo");
  };

  if (loading) {
    return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="p-6 lg:p-10 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold text-foreground">Conteúdo da home</h1>
        <p className="text-sm text-muted-foreground mt-1">Edite os textos da página inicial.</p>
      </div>

      <form onSubmit={save} className="space-y-5 rounded-xl border border-border bg-card p-6">
        <div className="space-y-2">
          <Label>Título principal</Label>
          <Input value={data.heroTitle} onChange={(e) => setData({ ...data, heroTitle: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Subtítulo</Label>
          <Textarea rows={2} value={data.heroSubtitle} onChange={(e) => setData({ ...data, heroSubtitle: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Texto do botão principal</Label>
          <Input value={data.heroCta} onChange={(e) => setData({ ...data, heroCta: e.target.value })} />
        </div>
        <div className="border-t border-border pt-5 space-y-5">
          <div className="space-y-2">
            <Label>Título da seção "Sobre"</Label>
            <Input value={data.aboutTitle} onChange={(e) => setData({ ...data, aboutTitle: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Texto da seção "Sobre"</Label>
            <Textarea rows={4} value={data.aboutText} onChange={(e) => setData({ ...data, aboutText: e.target.value })} />
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Salvar alterações
          </Button>
        </div>
      </form>
    </div>
  );
}
