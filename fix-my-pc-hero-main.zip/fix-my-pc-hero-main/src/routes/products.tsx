import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { z } from "zod";
import { motion } from "framer-motion";
import {
  Search, ShoppingBag, MessageCircle, X, Smartphone, Headphones,
  Cable, Shield, Tv, Tag, Check, Loader2,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { fetchPublicProducts, fetchSiteContent, type ProductRow, type SiteContent } from "@/lib/products";

type ProductsSearch = {
  q: string;
  cat: "todos" | "acessorios" | "celulares" | "perifericos" | "seguranca" | "audio";
  sort: "destaque" | "menor" | "maior" | "novo";
};

const productsSearchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  cat: fallback(
    z.enum(["todos", "acessorios", "celulares", "perifericos", "seguranca", "audio"]),
    "todos",
  ).default("todos"),
  sort: fallback(
    z.enum(["destaque", "menor", "maior", "novo"]),
    "destaque",
  ).default("destaque"),
});

export const Route = createFileRoute("/products")({
  validateSearch: zodValidator(productsSearchSchema),
  head: () => ({
    meta: [
      { title: "Produtos — Solução Celular" },
      { name: "description", content: "Catálogo completo de acessórios, smartphones, periféricos e equipamentos de segurança da Solução Celular." },
      { property: "og:title", content: "Produtos — Solução Celular" },
      { property: "og:description", content: "Acessórios originais, smartphones seminovos, câmeras CFTV, áudio e muito mais — com garantia." },
    ],
  }),
  component: ProductsPage,
});

const categories = [
  { id: "todos" as const, label: "Todos", icon: ShoppingBag },
  { id: "celulares" as const, label: "Celulares", icon: Smartphone },
  { id: "acessorios" as const, label: "Acessórios", icon: Cable },
  { id: "audio" as const, label: "Áudio", icon: Headphones },
  { id: "seguranca" as const, label: "Segurança", icon: Shield },
  { id: "perifericos" as const, label: "Periféricos", icon: Tv },
];

const sortOptions = [
  { id: "destaque", label: "Em destaque" },
  { id: "novo", label: "Mais novos" },
  { id: "menor", label: "Menor preço" },
  { id: "maior", label: "Maior preço" },
] as const;

const formatPrice = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function ProductsPage() {
  const { q, cat, sort } = Route.useSearch();
  const navigate = useNavigate({ from: "/products" });
  const [selected, setSelected] = useState<ProductRow | null>(null);
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [whatsapp, setWhatsapp] = useState<string>("5522998842964");

  useEffect(() => {
    fetchPublicProducts()
      .then(setProducts)
      .finally(() => setLoading(false));
    fetchSiteContent("contact").then((c) => {
      if (c?.whatsapp) setWhatsapp(c.whatsapp);
    });
  }, []);

  const whatsappLink = (productName: string) =>
    `https://wa.me/${whatsapp}?text=${encodeURIComponent(
      `Olá! Tenho interesse no produto: ${productName}. Pode me passar mais informações?`,
    )}`;

  const filtered = useMemo(() => {
    let list = products;
    if (cat !== "todos") list = list.filter((p) => p.category === cat);
    if (q.trim()) {
      const term = q.toLowerCase();
      list = list.filter(
        (p) => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term),
      );
    }
    const sorted = [...list];
    if (sort === "menor") sorted.sort((a, b) => Number(a.price) - Number(b.price));
    else if (sort === "maior") sorted.sort((a, b) => Number(b.price) - Number(a.price));
    else if (sort === "novo") sorted.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    else sorted.sort((a, b) => Number(!!b.highlight) - Number(!!a.highlight) || b.sort_order - a.sort_order);
    return sorted;
  }, [q, cat, sort, products]);

  return (
    <div className="pt-20">
      <section className="sticky top-20 z-30 border-b border-border bg-background/85 backdrop-blur-md">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                value={q}
                onChange={(e) =>
                  navigate({
                    search: (prev: ProductsSearch) => ({ ...prev, q: e.target.value }),
                    replace: true,
                  })
                }
                placeholder="Buscar produtos..."
                className="w-full rounded-xl border border-border bg-card pl-10 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground hidden sm:inline">Ordenar:</span>
              <select
                value={sort}
                onChange={(e) =>
                  navigate({
                    search: (prev: ProductsSearch) => ({
                      ...prev,
                      sort: e.target.value as ProductsSearch["sort"],
                    }),
                    replace: true,
                  })
                }
                className="rounded-xl border border-border bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                {sortOptions.map((o) => (
                  <option key={o.id} value={o.id}>{o.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-4 flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
            {categories.map((c) => {
              const active = c.id === cat;
              const Icon = c.icon;
              return (
                <button
                  key={c.id}
                  onClick={() =>
                    navigate({
                      search: (prev: ProductsSearch) => ({ ...prev, cat: c.id }),
                      replace: true,
                    })
                  }
                  className={`inline-flex items-center gap-2 whitespace-nowrap rounded-full border px-4 py-2 text-xs font-semibold transition-all ${
                    active
                      ? "border-primary bg-primary text-primary-foreground shadow-[0_4px_14px_-2px_var(--glow)]"
                      : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-primary/40"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {c.label}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">{filtered.length}</span>{" "}
              {filtered.length === 1 ? "produto encontrado" : "produtos encontrados"}
            </p>
          </div>

          {loading ? (
            <div className="grid place-items-center py-20">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="rounded-2xl border border-border bg-card p-12 text-center">
              <ShoppingBag className="mx-auto h-10 w-10 text-muted-foreground" />
              <p className="mt-4 text-foreground font-semibold">Nenhum produto encontrado</p>
              <p className="mt-1 text-sm text-muted-foreground">Tente ajustar a busca ou trocar de categoria.</p>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filtered.map((p, i) => {
                const price = Number(p.price);
                const oldPrice = p.old_price ? Number(p.old_price) : null;
                return (
                  <motion.article
                    key={p.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.35, delay: Math.min(i * 0.04, 0.3) }}
                    className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:glow-border hover:shadow-xl hover:shadow-primary/10"
                  >
                    <button
                      onClick={() => setSelected(p)}
                      className="relative aspect-square overflow-hidden bg-muted text-left"
                      aria-label={`Ver detalhes de ${p.name}`}
                    >
                      {p.image_url ? (
                        <img
                          src={p.image_url}
                          alt={p.name}
                          loading="lazy"
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      ) : (
                        <div className="h-full w-full grid place-items-center text-muted-foreground">
                          <ShoppingBag className="h-10 w-10" />
                        </div>
                      )}
                      {p.badge && (
                        <span className="absolute top-3 left-3 rounded-full border border-primary/40 bg-background/80 backdrop-blur px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-primary">
                          {p.badge}
                        </span>
                      )}
                      {oldPrice && oldPrice > price && (
                        <span className="absolute top-3 right-3 rounded-full bg-destructive/90 backdrop-blur px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-destructive-foreground">
                          -{Math.round(((oldPrice - price) / oldPrice) * 100)}%
                        </span>
                      )}
                    </button>

                    <div className="flex flex-1 flex-col p-5">
                      <h3 className="text-base font-semibold text-foreground line-clamp-1">{p.name}</h3>
                      <p className="mt-1 text-xs text-muted-foreground line-clamp-2 leading-relaxed">{p.description}</p>

                      <div className="mt-auto pt-4 flex items-end justify-between gap-2">
                        <div>
                          {oldPrice && oldPrice > price && (
                            <p className="text-xs text-muted-foreground line-through">{formatPrice(oldPrice)}</p>
                          )}
                          <p className="text-xl font-extrabold text-primary leading-tight">{formatPrice(price)}</p>
                        </div>
                      </div>

                      <div className="mt-3 grid grid-cols-2 gap-2">
                        <button
                          onClick={() => setSelected(p)}
                          className="rounded-lg border border-border bg-background px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:border-primary/40 hover:text-primary"
                        >
                          Detalhes
                        </button>
                        <a
                          href={whatsappLink(p.name)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground transition-all hover:opacity-90 glow-box"
                        >
                          <MessageCircle className="h-3.5 w-3.5" />
                          Comprar
                        </a>
                      </div>
                    </div>
                  </motion.article>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl p-0 overflow-hidden bg-card border-border">
          {selected && (
            <div className="grid md:grid-cols-2">
              <div className="relative aspect-square md:aspect-auto bg-muted">
                {selected.image_url ? (
                  <img src={selected.image_url} alt={selected.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full grid place-items-center text-muted-foreground">
                    <ShoppingBag className="h-16 w-16" />
                  </div>
                )}
                {selected.badge && (
                  <span className="absolute top-4 left-4 rounded-full border border-primary/40 bg-background/80 backdrop-blur px-2.5 py-1 text-[10px] font-bold uppercase tracking-wide text-primary">
                    {selected.badge}
                  </span>
                )}
              </div>
              <div className="flex flex-col p-6 sm:p-8">
                <DialogHeader className="space-y-2 text-left">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Tag className="h-3.5 w-3.5" />
                    <span className="capitalize">{selected.category}</span>
                  </div>
                  <DialogTitle className="text-2xl font-extrabold text-foreground">{selected.name}</DialogTitle>
                  <DialogDescription className="text-sm text-muted-foreground leading-relaxed">
                    {selected.long_description || selected.description}
                  </DialogDescription>
                </DialogHeader>

                <div className="mt-6">
                  {selected.old_price && Number(selected.old_price) > Number(selected.price) && (
                    <p className="text-sm text-muted-foreground line-through">{formatPrice(Number(selected.old_price))}</p>
                  )}
                  <p className="text-3xl font-extrabold text-primary">{formatPrice(Number(selected.price))}</p>
                </div>

                {selected.specs.length > 0 && (
                  <ul className="mt-5 space-y-2">
                    {selected.specs.map((s) => (
                      <li key={s} className="flex items-center gap-2 text-sm text-foreground">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/15">
                          <Check className="h-3 w-3 text-primary" />
                        </span>
                        {s}
                      </li>
                    ))}
                  </ul>
                )}

                <div className="mt-auto pt-6 flex flex-col gap-2">
                  <a
                    href={whatsappLink(selected.name)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground transition-all hover:opacity-90 glow-box"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Comprar pelo WhatsApp
                  </a>
                  <button
                    onClick={() => setSelected(null)}
                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-background px-5 py-2.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="h-4 w-4" />
                    Continuar navegando
                  </button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
