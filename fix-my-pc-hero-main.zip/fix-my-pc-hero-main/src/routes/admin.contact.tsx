import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchSiteContent, type SiteContent } from "@/lib/products";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/admin/contact")({
  component: AdminContactPage,
});

const defaults: SiteContent["contact"] = {
  phone: "",
  whatsapp: "",
  email: "",
  address: "",
  hours: "",
  instagram: "",
  facebook: "",
};

function AdminContactPage() {
  const [data, setData] = useState<SiteContent["contact"]>(defaults);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSiteContent("contact").then((d) => {
      if (d) setData({ ...defaults, ...d });
      setLoading(false);
    });
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase
      .from("site_content")
      .upsert({ key: "contact", value: data });
    setSaving(false);
    if (error) toast.error(error.message);
    else toast.success("Informações salvas");
  };

  if (loading) {
    return <div className="grid place-items-center py-20"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="p-6 lg:p-10 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-2xl font-extrabold text-foreground">Informações de contato</h1>
        <p className="text-sm text-muted-foreground mt-1">Dados exibidos no rodapé e na página de contato.</p>
      </div>

      <form onSubmit={save} className="space-y-5 rounded-xl border border-border bg-card p-6">
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Telefone</Label>
            <Input value={data.phone} onChange={(e) => setData({ ...data, phone: e.target.value })} placeholder="(11) 99999-9999" />
          </div>
          <div className="space-y-2">
            <Label>WhatsApp (apenas números)</Label>
            <Input value={data.whatsapp} onChange={(e) => setData({ ...data, whatsapp: e.target.value })} placeholder="5511999999999" />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Email</Label>
          <Input type="email" value={data.email} onChange={(e) => setData({ ...data, email: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Endereço</Label>
          <Textarea rows={2} value={data.address} onChange={(e) => setData({ ...data, address: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Horário de funcionamento</Label>
          <Input value={data.hours} onChange={(e) => setData({ ...data, hours: e.target.value })} />
        </div>
        <div className="border-t border-border pt-5 space-y-4">
          <div className="space-y-2">
            <Label>Instagram (URL)</Label>
            <Input value={data.instagram} onChange={(e) => setData({ ...data, instagram: e.target.value })} placeholder="https://instagram.com/..." />
          </div>
          <div className="space-y-2">
            <Label>Facebook (URL)</Label>
            <Input value={data.facebook} onChange={(e) => setData({ ...data, facebook: e.target.value })} placeholder="https://facebook.com/..." />
          </div>
        </div>
        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Salvar alterações
          </Button>
        </div>
      </form>
    </div>
  );
}
