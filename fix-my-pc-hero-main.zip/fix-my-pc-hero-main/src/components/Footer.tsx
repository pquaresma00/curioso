import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Mail } from "lucide-react";
import logoSolucao from "../assets/logo-solucao.png";

export function Footer() {
  return (
    <footer className="border-t border-border bg-surface">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-3">
          <div>
            <Link to="/" className="inline-flex items-center mb-4">
              <img src={logoSolucao} alt="Solução Celular" className="h-16 w-auto object-contain" />
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Especialistas em smartphones há mais de 20 anos. Em Rio das Ostras há 11 anos, oferecendo reparos com agilidade, transparência e qualidade.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">Navegação</h3>
            <div className="flex flex-col gap-3">
              <Link to="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">Início</Link>
              <Link to="/products" className="text-sm text-muted-foreground hover:text-primary transition-colors">Produtos</Link>
              <Link to="/about" className="text-sm text-muted-foreground hover:text-primary transition-colors">Sobre nós</Link>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">Contato</h3>
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                (22) 99884-2964
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                sollucaocelular@gmail.com
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 text-primary" />
                Rio das Ostras, RJ - Rua Santa Catarina, N° 666, Cidade Praiana
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-8 text-center text-xs text-muted-foreground">
          <p>© {new Date().getFullYear()} Solução Celular. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
