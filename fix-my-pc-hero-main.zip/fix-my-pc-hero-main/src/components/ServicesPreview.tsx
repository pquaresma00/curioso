import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import useEmblaCarousel from "embla-carousel-react";
import { X, ImageIcon, Loader2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { whatsappLink } from "@/lib/whatsapp";
import { fetchPublicServices, type ServiceRow } from "@/lib/services";

function ServiceCarousel({
  images,
  title,
  onImageClick,
}: {
  images: string[];
  title: string;
  onImageClick: (index: number) => void;
}) {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: images.length > 1 });
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSelectedIndex(emblaApi.selectedScrollSnap());
    emblaApi.on("select", onSelect);
    return () => {
      emblaApi.off("select", onSelect);
    };
  }, [emblaApi]);

  const hasMultiple = images.length > 1;

  if (images.length === 0) {
    return (
      <div className="relative aspect-square overflow-hidden bg-muted grid place-items-center text-muted-foreground">
        <ImageIcon className="h-10 w-10" />
      </div>
    );
  }

  return (
    <div className="relative aspect-square overflow-hidden bg-muted">
      <div className="h-full overflow-hidden" ref={emblaRef}>
        <div className="flex h-full touch-pan-y">
          {images.map((src, i) => (
            <div key={i} className="relative h-full min-w-0 flex-[0_0_100%] overflow-hidden">
              <button
                type="button"
                onClick={() => onImageClick(i)}
                className="block h-full w-full"
                aria-label={`Ampliar imagem ${i + 1} de ${title}`}
              >
                <img
                  src={src}
                  alt={`${title} — imagem ${i + 1}`}
                  loading="lazy"
                  draggable={false}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 select-none"
                />
              </button>
            </div>
          ))}
        </div>
      </div>

      {hasMultiple && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
          {images.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                emblaApi?.scrollTo(i);
              }}
              className={`h-1.5 rounded-full transition-all ${
                i === selectedIndex ? "w-6 bg-primary" : "w-1.5 bg-background/70"
              }`}
              aria-label={`Ir para imagem ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ImageLightbox({
  images,
  startIndex,
  title,
  open,
  onOpenChange,
}: {
  images: string[];
  startIndex: number;
  title: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [emblaRef] = useEmblaCarousel({
    loop: images.length > 1,
    startIndex,
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl p-0 overflow-hidden bg-card border-border">
        <div className="relative">
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex touch-pan-y">
              {images.map((src, i) => (
                <div key={i} className="min-w-0 flex-[0_0_100%]">
                  <img
                    src={src}
                    alt={`${title} — imagem ${i + 1}`}
                    draggable={false}
                    className="w-full h-auto max-h-[80vh] object-contain bg-black select-none"
                  />
                </div>
              ))}
            </div>
          </div>

          {images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-background/80 backdrop-blur px-3 py-1 text-[11px] text-muted-foreground pointer-events-none">
              Arraste para ver mais
            </div>
          )}

          <button
            type="button"
            onClick={() => onOpenChange(false)}
            className="absolute top-3 right-3 h-9 w-9 flex items-center justify-center rounded-full bg-background/80 backdrop-blur border border-border hover:bg-background transition"
            aria-label="Fechar"
          >
            <X className="h-4 w-4" />
          </button>

          <div className="absolute top-3 left-3 rounded-full bg-background/80 backdrop-blur px-3 py-1 text-xs text-muted-foreground">
            {title}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function ServicesPreview() {
  const [services, setServices] = useState<ServiceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [lightbox, setLightbox] = useState<{ images: string[]; title: string; index: number } | null>(null);

  useEffect(() => {
    fetchPublicServices()
      .then(setServices)
      .catch(() => setServices([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <section className="py-24 bg-surface">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-extrabold sm:text-4xl">
            Nossos <span className="text-gradient">serviços</span>
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Catálogo completo de serviços e soluções para o seu equipamento.
          </p>
        </motion.div>

        {loading ? (
          <div className="grid place-items-center py-20">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : services.length === 0 ? (
          <p className="text-center text-muted-foreground py-12">Nenhum serviço cadastrado.</p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service, i) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="group relative overflow-hidden rounded-2xl border border-border bg-card transition-all hover:glow-border hover:shadow-lg hover:shadow-primary/10 hover:-translate-y-1"
              >
                <div className="relative">
                  <ServiceCarousel
                    images={service.images}
                    title={service.title}
                    onImageClick={(index) =>
                      setLightbox({ images: service.images, title: service.title, index })
                    }
                  />
                  {service.badge && (
                    <div className="absolute top-3 right-3 z-10 pointer-events-none">
                      <span className="rounded-full border border-primary/40 bg-background/80 backdrop-blur px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-primary">
                        {service.badge}
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-foreground">{service.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{service.description}</p>
                  <div className="mt-5 pt-4 border-t border-border/60">
                    <a
                      href={whatsappLink(`Olá! Gostaria de um orçamento sobre: ${service.title}.`)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:gap-2 transition-all"
                    >
                      Solicitar orçamento →
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="mt-12 text-center">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
          >
            Ver todos os produtos →
          </Link>
        </div>
      </div>

      {lightbox && (
        <ImageLightbox
          images={lightbox.images}
          startIndex={lightbox.index}
          title={lightbox.title}
          open={!!lightbox}
          onOpenChange={(o) => !o && setLightbox(null)}
        />
      )}
    </section>
  );
}
