import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import Autoplay from "embla-carousel-autoplay";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from "@/components/ui/carousel";
import { useRef } from "react";

const testimonials = [
  {
    name: "Diana Pentracine",
    text: "Ótimo atendimento e rápida reparação do telefone, peças de muita qualidade! Além da atendente ser super simpática e carismática! Volto sempre!!",
    rating: 5,
    when: "1 ano atrás",
  },
  {
    name: "Pamela Oliveira",
    text: "Atendimento maravilhoso, são super atenciosos, e muita agilidade com o trabalho. Preço ótimo que cabe no bolso e a garantia do serviço oferecido por eles é top de mais.",
    rating: 5,
    when: "10 meses atrás",
  },
  {
    name: "Samuel Carvalho",
    text: "A Soluções Celular e a loja que sempre que preciso, levo aparelhos para fazer consertos, troca de tela e etc. Super recomendo",
    rating: 5,
    when: "5 meses atrás",
  },
  {
    name: "Edir Ferreira Baiense",
    text: "Resolveram meu problema bem rápido em 3 minutos, muito bom, volto aqui sempre",
    rating: 5,
    when: "6 meses atrás",
  },
  {
    name: "Wendel Emanoel",
    text: "Ótimo atendimento, serviço de qualidade!!",
    rating: 5,
    when: "4 meses atrás",
  },
  {
    name: "Jairo Cassiano",
    text: "Essa e a melhor loja de celular de Rio das Ostras a 11 que conheço sempre com a mesma excelência e qualidade!",
    rating: 5,
    when: "3 meses atrás",
  },
];

export function TestimonialsSection() {
  const autoplay = useRef(
    Autoplay({ delay: 5000, stopOnInteraction: true, stopOnMouseEnter: true })
  );

  return (
    <section className="py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl font-extrabold sm:text-4xl">
            O que nossos <span className="text-gradient">clientes</span> dizem
          </h2>
          <p className="mt-4 text-muted-foreground">
            Avaliações reais de quem já passou pela Solução Celular
          </p>
        </motion.div>

        <Carousel
          opts={{ align: "start", loop: true }}
          plugins={[autoplay.current]}
          className="mx-auto max-w-6xl px-4 sm:px-12"
        >
          <CarouselContent>
            {testimonials.map((t, i) => (
              <CarouselItem key={t.name} className="md:basis-1/2 lg:basis-1/3">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.05 }}
                  className="h-full rounded-2xl border border-border bg-card p-6 hover:border-primary/40 transition-all relative"
                >
                  <Quote className="absolute top-4 right-4 h-8 w-8 text-primary/20" />
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: t.rating }).map((_, j) => (
                      <Star
                        key={j}
                        className="h-4 w-4 fill-primary text-primary"
                      />
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-6">
                    "{t.text}"
                  </p>
                  <div className="flex items-center gap-3 pt-4 border-t border-border">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/15 text-primary font-semibold text-sm">
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-foreground">
                        {t.name}
                      </p>
                      <p className="text-xs text-muted-foreground">{t.when}</p>
                    </div>
                  </div>
                </motion.div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden sm:flex" />
          <CarouselNext className="hidden sm:flex" />
        </Carousel>
      </div>
    </section>
  );
}
