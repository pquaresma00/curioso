import { Link } from "@tanstack/react-router";
import { Menu, X, MessageCircle } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import logoSolucao from "../assets/logo-solucao.png";

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <Link to="/" className="flex items-center">
            <img src={logoSolucao} alt="Solução" className="h-16 w-auto object-contain" />
          </Link>

          <nav className="hidden items-center gap-8 md:flex">
            <Link to="/" className="text-sm text-muted-foreground transition-colors hover:text-foreground" activeProps={{ className: "text-sm text-primary font-medium" }}>
              Início
            </Link>
            <Link to="/products" className="text-sm text-muted-foreground transition-colors hover:text-foreground" activeProps={{ className: "text-sm text-primary font-medium" }}>
              Produtos
            </Link>
            <Link to="/about" className="text-sm text-muted-foreground transition-colors hover:text-foreground" activeProps={{ className: "text-sm text-primary font-medium" }}>
              Sobre nós
            </Link>
          </nav>

          <div className="hidden items-center gap-4 md:flex">
            <a href="https://wa.me/5522998842964?text=Ol%C3%A1!%20Gostaria%20de%20falar%20com%20um%20atendente." target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 glow-box">
              <MessageCircle className="h-4 w-4" />
              WhatsApp
            </a>
          </div>

          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden text-foreground">
            {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-border md:hidden glass"
          >
            <div className="flex flex-col gap-4 px-4 py-6">
              <Link to="/" onClick={() => setMenuOpen(false)} className="text-sm text-muted-foreground hover:text-foreground">Início</Link>
              <Link to="/products" onClick={() => setMenuOpen(false)} className="text-sm text-muted-foreground hover:text-foreground">Produtos</Link>
              <Link to="/about" onClick={() => setMenuOpen(false)} className="text-sm text-muted-foreground hover:text-foreground">Sobre nós</Link>
              <a href="https://wa.me/5522998842964?text=Ol%C3%A1!%20Gostaria%20de%20falar%20com%20um%20atendente." target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground">
                <MessageCircle className="h-4 w-4" />
                WhatsApp
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
