import { motion } from "framer-motion";
import { Zap, ShieldCheck, Clock } from "lucide-react";
import { useState, useEffect } from "react";
import heroPhones from "../assets/hero-phones-transparent.png";
import heroBg from "../assets/hero-bg.jpg";
import { whatsappLink } from "@/lib/whatsapp";

export function HeroSection() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <section className="relative flex items-center justify-center overflow-hidden pt-20">
      {/* Background image - space + tech repair theme */}
      <div
        className="absolute inset-0 brightness-[0.6]"
        style={{
          backgroundImage: `url(${heroBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      />
      {/* Gradient overlay for contrast */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/50 to-background/70" />

      <div className="relative mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-6">
          {/* Text content */}
          {mounted ? (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex-1 text-center lg:text-left"
            >
              <HeroTextContent />
            </motion.div>
          ) : (
            <div className="flex-1 text-center lg:text-left">
              <HeroTextContent />
            </div>
          )}

          {/* Hero image with floating effect */}
          {mounted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative flex flex-1 justify-center lg:justify-end"
            >
              <HeroImageContent mounted={mounted} />
            </motion.div>
          ) : (
            <div className="relative flex flex-1 justify-center lg:justify-end">
              <HeroImageContent mounted={false} />
            </div>
          )}
        </div>

        {mounted ? (
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 grid gap-6 sm:grid-cols-3"
          >
            <HeroFeatures />
          </motion.div>
        ) : (
          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            <HeroFeatures />
          </div>
        )}
      </div>
    </section>
  );
}

function HeroTextContent() {
  return (
    <>
      <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-xs font-medium text-primary mb-8">
        <Zap className="h-3.5 w-3.5" />
        Atendimento em até 24h
      </div>

      <h1 className="text-4xl font-extrabold tracking-tight sm:text-6xl lg:text-7xl">
        Seu smartphone
        <br />
        <span className="text-gradient">como novo.</span>
      </h1>

      <p className="mt-6 max-w-2xl text-lg text-muted-foreground leading-relaxed">
        Especialistas em conserto de celulares. Também reparamos tablets, notebooks e videogames com qualidade e garantia.
      </p>

      <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center lg:justify-start">
        <a
          href={whatsappLink("Olá! Gostaria de solicitar um orçamento.")}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center rounded-xl bg-primary px-8 py-3.5 text-sm font-bold text-primary-foreground transition-all hover:opacity-90 glow-box"
        >
          Solicitar orçamento grátis
        </a>
        <a
          href={whatsappLink("Olá! Gostaria de falar com um atendente.")}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center rounded-xl border border-border bg-secondary px-8 py-3.5 text-sm font-medium text-secondary-foreground transition-colors hover:bg-muted"
        >
          Ligar agora
        </a>
      </div>
    </>
  );
}

function HeroImageContent({ mounted }: { mounted: boolean }) {
  return (
    <>
      {/* Soft glow behind phones */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[380px] h-[380px] sm:w-[480px] sm:h-[480px] lg:w-[560px] lg:h-[560px] rounded-full bg-primary/28 blur-[120px]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[45%] w-[260px] h-[260px] sm:w-[320px] sm:h-[320px] lg:w-[380px] lg:h-[380px] rounded-full bg-primary/20 blur-[70px]" />
      {mounted ? (
        <motion.img
          src={heroPhones}
          alt="Celular com tela quebrada sendo consertado"
          className="relative z-10 w-[320px] sm:w-[400px] lg:w-[460px] drop-shadow-2xl"
          animate={{ y: [0, -16, 0] }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ) : (
        <img
          src={heroPhones}
          alt="Celular com tela quebrada sendo consertado"
          className="relative z-10 w-[320px] sm:w-[400px] lg:w-[460px] drop-shadow-2xl"
        />
      )}
    </>
  );
}

function HeroFeatures() {
  return (
    <>
      {[
        { icon: Clock, title: "Rápido", desc: "Maioria dos reparos em até 48h" },
        { icon: ShieldCheck, title: "Garantia", desc: "Garantia de até 1 ano" },
        { icon: Zap, title: "Diagnóstico grátis", desc: "Avaliamos sem compromisso" },
      ].map((item) => (
        <div key={item.title} className="rounded-2xl border border-border bg-card p-6 text-center glow-border">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
            <item.icon className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-sm font-semibold text-foreground">{item.title}</h3>
          <p className="mt-1 text-xs text-muted-foreground">{item.desc}</p>
        </div>
      ))}
    </>
  );
}
