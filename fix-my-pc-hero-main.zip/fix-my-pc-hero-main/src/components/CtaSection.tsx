import { motion } from "framer-motion";
import { whatsappLink } from "@/lib/whatsapp";

export function CtaSection() {
  return (
    <section className="py-24 bg-surface">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 to-transparent p-12 text-center sm:p-16 glow-box"
        >
          <h2 className="text-3xl font-extrabold sm:text-4xl text-foreground">
            Precisa de ajuda com seu equipamento?
          </h2>
          <p className="mt-4 text-muted-foreground max-w-lg mx-auto">
            Entre em contato agora e receba um diagnóstico gratuito. Sem compromisso, sem surpresas.
          </p>
          <div className="mt-8 flex justify-center">
            <a
              href={whatsappLink("Olá! Preciso falar com um técnico sobre meu equipamento.")}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center rounded-xl bg-primary px-8 py-3.5 text-sm font-bold text-primary-foreground transition-all hover:opacity-90"
            >
              Falar com um técnico
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
