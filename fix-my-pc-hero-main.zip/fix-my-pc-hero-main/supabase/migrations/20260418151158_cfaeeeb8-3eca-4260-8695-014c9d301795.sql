
-- ============================================================
-- 1. ROLES
-- ============================================================
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles"
  ON public.user_roles FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ============================================================
-- 2. UPDATED_AT trigger helper
-- ============================================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- ============================================================
-- 3. PRODUCTS
-- ============================================================
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  long_description TEXT NOT NULL DEFAULT '',
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  old_price NUMERIC(10,2),
  category TEXT NOT NULL DEFAULT 'acessorios',
  image_url TEXT NOT NULL DEFAULT '',
  badge TEXT,
  highlight BOOLEAN NOT NULL DEFAULT false,
  active BOOLEAN NOT NULL DEFAULT true,
  specs TEXT[] NOT NULL DEFAULT '{}',
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active products"
  ON public.products FOR SELECT
  USING (active = true OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert products"
  ON public.products FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update products"
  ON public.products FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete products"
  ON public.products FOR DELETE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_products_active ON public.products(active);
CREATE INDEX idx_products_category ON public.products(category);

-- ============================================================
-- 4. SITE CONTENT (key-value JSON for flexible page content)
-- ============================================================
CREATE TABLE public.site_content (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read site content"
  ON public.site_content FOR SELECT
  USING (true);

CREATE POLICY "Admins can manage site content"
  ON public.site_content FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER site_content_updated_at
  BEFORE UPDATE ON public.site_content
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed initial content
INSERT INTO public.site_content (key, value) VALUES
  ('home', '{"heroTitle":"Solução Celular","heroSubtitle":"Assistência técnica especializada e acessórios originais","heroCta":"Ver produtos","aboutTitle":"Por que nos escolher","aboutText":"Anos de experiência em reparos com peças originais e garantia."}'::jsonb),
  ('contact', '{"phone":"(11) 99999-9999","whatsapp":"5511999999999","email":"contato@solucaocelular.com.br","address":"Rua Exemplo, 123 - São Paulo, SP","hours":"Seg a Sex: 9h - 18h | Sáb: 9h - 13h","instagram":"https://instagram.com/solucaocelular","facebook":""}'::jsonb);

-- Seed initial products
INSERT INTO public.products (name, description, long_description, price, old_price, category, image_url, badge, highlight, specs, sort_order) VALUES
  ('iPhone 12 Seminovo 128GB', 'Aparelho revisado, bateria 90%+, com garantia de 90 dias.', 'iPhone 12 com 128GB de armazenamento, totalmente revisado pela nossa equipe técnica. Bateria com saúde acima de 90%, acompanha cabo e adaptador. Garantia de 90 dias contra defeitos de fabricação.', 2499, 2899, 'celulares', '', 'Oferta', true, ARRAY['128GB','Bateria 90%+','Garantia 90 dias','Acompanha cabo'], 9),
  ('Bateria Original Samsung', 'Bateria original com 1 ano de garantia para linha Galaxy.', 'Bateria 100% original Samsung, compatível com diversos modelos Galaxy. Instalação em 30 minutos com 1 ano de garantia total.', 189, NULL, 'acessorios', '', '1 ano garantia', false, ARRAY['100% original','1 ano de garantia','Instalação inclusa'], 8),
  ('Película 3D Cerâmica', 'Proteção total contra impactos, transparência cristalina.', 'Película 3D em cerâmica flexível, instalação grátis. Resistente a impactos e arranhões, mantém a sensibilidade do touch.', 39, 59, 'acessorios', '', 'Mais vendido', false, ARRAY['Material cerâmico','Instalação grátis','Toque preservado'], 7),
  ('Tela Original iPhone', 'Display original com até 1 ano de garantia.', 'Tela original Apple para diversos modelos de iPhone. Troca rápida com 1 ano de garantia. Mantém True Tone e Face ID quando aplicável.', 599, NULL, 'acessorios', '', 'Original', true, ARRAY['Tela original','True Tone','1 ano de garantia'], 6),
  ('Kit CFTV 4 Câmeras', 'Kit completo instalado e configurado no seu celular.', 'Kit com 4 câmeras Full HD, DVR, fonte e cabos. Instalação e configuração no app do celular incluída. Visualização remota 24h.', 1290, 1490, 'seguranca', '', 'Instalação inclusa', false, ARRAY['4 câmeras Full HD','DVR + acessórios','App de visualização','Suporte técnico'], 5),
  ('Carregador Turbo 65W', 'Carregamento ultra rápido USB-C, certificado.', 'Carregador 65W com tecnologia GaN, super compacto. Compatível com smartphones, tablets e até notebooks USB-C.', 149, NULL, 'acessorios', '', NULL, false, ARRAY['65W GaN','USB-C PD','Multi-dispositivo'], 4),
  ('Fone Bluetooth Premium', 'Cancelamento de ruído ativo, autonomia de 30h.', 'Fone TWS com ANC (cancelamento de ruído ativo), Bluetooth 5.3 e estojo com 30h de autonomia total.', 249, 329, 'audio', '', 'Novo', false, ARRAY['ANC ativo','Bluetooth 5.3','30h bateria','Resistência IPX4'], 3),
  ('Controle PS5 DualSense', 'Controle original Sony, novo lacrado.', 'DualSense original Sony com vibração háptica e gatilhos adaptativos. Produto novo, lacrado, com nota fiscal.', 449, NULL, 'perifericos', '', 'Lacrado', false, ARRAY['Original Sony','Vibração háptica','Gatilhos adaptativos'], 2),
  ('Antivírus + Backup 1 ano', 'Proteção completa para PC e celular.', 'Licença anual de antivírus premium com backup em nuvem incluso. Instalação e configuração feitas pela nossa equipe.', 129, NULL, 'seguranca', '', NULL, false, ARRAY['Licença 1 ano','Backup em nuvem','Instalação inclusa'], 1);

-- ============================================================
-- 5. STORAGE bucket for product images
-- ============================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true);

CREATE POLICY "Product images are publicly accessible"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'product-images');

CREATE POLICY "Admins can upload product images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update product images"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete product images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'product-images' AND public.has_role(auth.uid(), 'admin'));
