UPDATE public.site_content
SET value = jsonb_set(value, '{whatsapp}', '"5522998842964"'::jsonb),
    updated_at = now()
WHERE key = 'contact';