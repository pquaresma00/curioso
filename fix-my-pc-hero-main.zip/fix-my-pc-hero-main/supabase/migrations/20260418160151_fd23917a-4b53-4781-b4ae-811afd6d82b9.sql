-- Tabela de serviços
CREATE TABLE public.services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  badge TEXT,
  images TEXT[] NOT NULL DEFAULT '{}',
  highlight BOOLEAN NOT NULL DEFAULT false,
  active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active services"
  ON public.services
  FOR SELECT
  USING (active = true OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can insert services"
  ON public.services
  FOR INSERT
  TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update services"
  ON public.services
  FOR UPDATE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete services"
  ON public.services
  FOR DELETE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_services_updated_at
  BEFORE UPDATE ON public.services
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Seed com os 9 serviços atuais (imagens vazias por enquanto — admin vai subir pelo painel)
INSERT INTO public.services (title, description, badge, sort_order, images) VALUES
  ('Baterias originais', 'Troca de bateria com 1 ano de garantia. Sabemos que a bateria é o coração do seu aparelho.', '1 ano de garantia', 1, '{}'),
  ('Trocas de telas originais', 'Telas originais e de 1ª linha com até 1 ano de garantia para o seu celular.', 'Até 1 ano', 2, '{}'),
  ('Câmeras de segurança (CFTV)', 'Kit com 4 câmeras já instaladas e configuradas no celular. Manutenção e instalação.', 'Kit completo', 3, '{}'),
  ('Qualidade, garantia & bom preço', 'Tudo em acessórios e reparos para toda linha de smartphones e tablets.', 'Nós garantimos', 4, '{}'),
  ('Todos os tipos de conserto', 'Por que deixar assim? Entendemos que cada problema é único. Diagnóstico preciso para qualquer falha.', 'Diagnóstico grátis', 5, '{}'),
  ('Delivery do seu celular', 'Busca, conserta e leva. Agora você não precisa sair de casa, a Assistência Técnica vai até você!', 'Rápido e seguro', 6, '{}'),
  ('Acessórios para celular', 'Os melhores acessórios só a Solução tem. Acessórios de qualidade para o seu smartphone.', 'Loja completa', 7, '{}'),
  ('Assistência certificada', 'Solução Celular: certificada Best Award 2024 em Assistência Técnica Especializada.', 'Best Award 2024', 8, '{}'),
  ('Conserto de videogames', 'Encomende já o seu videogame conosco. PlayStation, Xbox e todas as plataformas.', 'Todas as plataformas', 9, '{}');